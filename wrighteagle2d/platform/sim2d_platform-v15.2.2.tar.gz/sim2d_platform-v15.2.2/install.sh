#!/bin/bash

sudo cp sources.list /etc/apt/sources.list

sudo apt-get update

sudo apt-get install -y build-essential libboost-all-dev flex 

sudo apt-get install -y libqt4-dev libxpm-dev libaudio-dev libxt-dev libpng-dev libglib2.0-dev libfreetype6-dev libxrender-dev libxext-dev libfontconfig-dev libxi-dev

tar -zxvf bison-2.7.1.tar.gz
cd bison-2.7.1
./configure
make
sudo make install
cd ..

sudo ldconfig

tar -zxvf rcssserver-15.2.2.tar.gz
cd rcssserver-15.2.2 
./configure --with-boost-libdir=/usr/lib/x86_64-linux-gnu
make
sudo make install
cd ..

tar -zxvf rcsslogplayer-15.1.0.tar.gz
cd rcsslogplayer-15.1.0
./configure --disable-gl --with-boost-libdir=/usr/lib/x86_64-linux-gnu
make
sudo make install
cd ..

tar -zxvf rcssmonitor-15.1.0.tar.gz
cd rcssmonitor-15.1.0 
./configure --with-boost-libdir=/usr/lib/x86_64-linux-gnu
make
sudo make install
cd ..

sudo ldconfig

